import { useEffect } from "react";
import { useSelector, useDispatch } from 'react-redux';
import useNudgeKeyboardHandler from "./hooks/useNudgeKeyboardHandler";
import useDefaultTemplate from "./hooks/useDefaultTemplate"; 
import useCanvasResize from "./hooks/useResizeCanvas";
import { setMode, setAppUpdateStatus, setUserIsAuth, setUnlockCount } from "./features/viewSlice";
import { eMode, PDF_VIEWERS, getUnlockStates } from "./constants";
import { checkLocalLicense, loadUnlockCount } from './services/localLicenseMananger';
import Canvas from "./components/Canvas";
import ToolBar from "./components/ToolBar";
import Header from "./components/Header";
import SideMenu from "./components/SideMenu";
import { Spinner } from "./components/UIkit/Spinner";
import DialoguePanelManager from "./dialoguePanels/PanelManager";
import { loadImageDirectoryData } from "./loaders";

// test accounts logins
// N2WH-A76G-I3OA aaaa
// N26J-4T4O-UYQA bbbb

const App = () => {

	const dispatch = useDispatch();
	const view = useSelector(state => state.view);
	const loadDefaultTemplate = useDefaultTemplate();
	useNudgeKeyboardHandler();
	useCanvasResize();
	
	// Progress bar handling
	useEffect(() => {
		if (window && window.electronAPI) {
			window.electronAPI.onUpdateProgress((event, progress) => {
				dispatch(setMode(eMode.APP_UPDATING));
				dispatch(setAppUpdateStatus({ percent: progress.percent }));
			});
			window.electronAPI.onUpdateError(() => {
				dispatch(setAppUpdateStatus({}));
				dispatch(setMode(null));
			});
		}
	}, []);

	useEffect(() => {
		async function fetchData() {
			await loadImageDirectoryData();
			const licence = await checkLocalLicense();
			dispatch(setUserIsAuth(licence))
			const unlockCount = loadUnlockCount();
			dispatch(setUnlockCount(unlockCount))
			if (!licence) {
				dispatch(setMode(eMode.USER_OPTIONS));
			} else {
				// Speech Builder is the default landing screen, but if it's
				// locked, open on the first unlocked PDF viewer instead.
				const unlockStates = getUnlockStates(unlockCount);
				const speechBuilderLocked = !unlockStates[0].unlocked;
				if (speechBuilderLocked) {
					const firstUnlockedViewer = PDF_VIEWERS.find((_, index) => unlockStates[index + 1].unlocked);
					if (firstUnlockedViewer) {
						dispatch(setMode(firstUnlockedViewer.mode));
					}
				}
			}
			loadDefaultTemplate()
		}
		fetchData();
	}, []);

	return (
		<div className="app">
			{view.userIsAuth && <Canvas />}
			<ToolBar />
			<Header />
			<SideMenu />
			<DialoguePanelManager />
			{view.showLoader && <Spinner />}
		</div>
	);
}





export default App;

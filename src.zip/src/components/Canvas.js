import { useState, useRef, useEffect } from "react"; // Add useRef import
import { useSelector, useDispatch } from 'react-redux'
import { cx } from '../styles';
import { eMode, eDirection } from "../constants";
import useCanvasFileLoader from "../hooks/useCanvasFileLoader"; 
import TransformWidget from "./TransformWidget";
import { BrushSVG } from "./BrushSVG";
import { getHighestZdepth } from "../utils";

import {
	storeHistroy,
} from "../actions";

import { 
	setSelectedIndex, 
	updateTemplateData, 
	updateImageData, 
	updateTextData, 
} from "../features/canvasSlice";

import { 
	setMode, 
	setDragIndex,
} from "../features/viewSlice";


let clickOffset = {};

const Canvas = () => {
	const dispatch = useDispatch();
	const view = useSelector(state => state.view);
	const canvas = useSelector(state => state.canvas);
	const canvasRef = useRef(null);
	const [canvasDimensions, setCanvasDimensions] = useState({ left: 0 });
	const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
	const [panx, setPanx] = useState(0);
	const [pany, setPany] = useState(0);
	const [zoom, setZoom] = useState(1);
	
	const orientation	= canvas.orientation || "portrait";
	const canvasScale 	= view.canvasScale * (orientation === "portrait" ? 1 : 1.43);
	const mode 			= view.mode;
	const dragIndex 	= view.dragIndex;
	const brushColour 	= view.brushColour;
	const selectedIndex = canvas.selectedIndex;
	const images 		= canvas.images || [];
	const textData 		= canvas.texts || [];
	const template 		= canvas.template;
	const canvasTop 	= view.fullScreen ? "15px" : null;

	useEffect(() => {
        if (canvasRef.current) {
            const rect = canvasRef.current.getBoundingClientRect();
            const left = window.innerWidth/2 - rect.width/2 + 30; // + for toolbar
            setCanvasDimensions({ left});
        }
    }, [canvasScale, orientation]); 
	const canvasLeft = canvasDimensions.left;

	useCanvasFileLoader();
	
	const updateData = (index, key, value) => {
		switch (mode) {
			case eMode.EDIT_IMAGE: dispatch(updateImageData({index, key, value})); break;
			case eMode.COLOUR_IMAGE: dispatch(updateImageData({index, key, value})); break;
			case eMode.EDIT_TEXT: dispatch(updateTextData({key, value})); break;
			default: break;
		}
	};

	//---------------------
	// ON DOWN
	//---------------------

	const onImageTouch = (e, index, nextMode) => {
		var evt = (typeof e.originalEvent === 'undefined') ? e : e.originalEvent;
		var touch = evt.touches[0] || evt.changedTouches[0];
		onDown(touch.pageX, touch.pageY, index, nextMode);
	}

	const onImageClick = (evt, index, nextMode) => {
		onDown(evt.clientX, evt.clientY, index, nextMode);
	}

	const onDown = (downX, downY, index, nextMode) => {
		if (mode !== eMode.COLOUR_IMAGE) {
			dispatch(setMode(nextMode));
		}

		const el = document.elementsFromPoint(downX, downY);
		let elementSelectDone = false; // we only want to select one (topmost if stacked) element
		let stopScan = false; // once true, everything remaining in `el` is a lower, visually-obscured layer

		for (var i in el) {
			if (stopScan) break;

			if (el[i] && el[i].nodeName === "use" && !elementSelectDone) {
				let fillId = el[i].getAttribute("xlink:href");
				fillId = fillId.substr(1, fillId.length - 1);
				const fill = document.getElementById(fillId); // node
				// console.log('fillId ', fillId)
				const fillIdStoreId = fillId.split("^")[1]; // string
				// console.log('fillIdStoreId ', fillIdStoreId)
				const path = fill.querySelector("path");
				
				// get (parent) index from clicked region 
				let s1 = fillId.split("^");
				index = Math.floor(s1[0].split('_')[1]);
				// console.log(index)

				const isTemplate = fillId.indexOf('template') !== -1;
				console.log('isTemplate ', isTemplate);
				// console.log('path ', path);

				// if (isTemplate){
				// 	dispatch(setSelectedIndex(null));
				// }

				// if colouring active then apply colour
				if (brushColour) {
					if (path) {
						// don't colour outline
						if (fillIdStoreId.substr(0, 7) === "outline") return;
						// is it a template? and locked?
						// if (isTemplate && !view.templateLock) return;
						// superficially colour dom
						path.setAttribute("fill", brushColour);
						// store colour	for saving	
						if (view.mode === eMode.COLOUR_IMAGE) {
							if (isTemplate){ // isNaN(index)
								dispatch(updateTemplateData({key:fillIdStoreId, value:brushColour}))
	
							} else {
								dispatch(updateImageData({index, key:fillIdStoreId, value:brushColour}));
								// update whole svg data - so when we clone the imgage the svg contained the colours 
								const el = document.getElementById("image-"+index);
								if (el){
									const svgmarkup = el.innerHTML;
									dispatch(updateImageData({index, key:'svg', value:svgmarkup}));
								}
							}
						} 
					}
				}

				
				// if NOT colouring then drag / activated transform widget
				if (!brushColour) {
					dispatch(setDragIndex(index));
					dispatch(setSelectedIndex(index));
					updateData(index, "zIndex", getHighestZdepth(images));

					//set offset to
					const canvasRect = document.getElementById("canvas").getBoundingClientRect();
					const imageEl = document.getElementById("image-" + index);
					if (imageEl) {
						const imageRect = imageEl.getBoundingClientRect();
						const x = downX - imageRect.left - imageRect.width / 2 + canvasRect.left;
						const y = downY - imageRect.top - imageRect.height / 2 + canvasRect.top;
						clickOffset = { x, y };
					}
				}

				elementSelectDone = true;
			}

			// A raster image (e.g. a "My Images" upload) has no <use> fill regions,
			// so reaching its container without a match means this pixel is genuinely
			// its topmost content - stop before the scan falls through to whatever's
			// underneath (e.g. a template) and wrongly selects that instead.
			// SVG clipart images are deliberately NOT stopped here: their unpainted
			// "alpha" areas have no hit-testable geometry at this pixel, so letting
			// the scan continue is what allows selecting a lower SVG through them.
			if (el[i] && el[i].id && el[i].id.indexOf("image-") === 0) {
				const hitIndex = Math.floor(el[i].id.slice("image-".length));
				if (images[hitIndex]?.raster) {
					stopScan = true;
				}
			}
		}

		// Raster images (e.g. "My Images" uploads) have no <use> fill regions for
		// the loop above to key off, so select/drag them directly by index instead.
		if (!elementSelectDone && !brushColour && images[index]?.raster) {
			dispatch(setDragIndex(index));
			dispatch(setSelectedIndex(index));
			updateData(index, "zIndex", getHighestZdepth(images));

			const canvasRect = document.getElementById("canvas").getBoundingClientRect();
			const imageEl = document.getElementById("image-" + index);
			if (imageEl) {
				const imageRect = imageEl.getBoundingClientRect();
				const x = downX - imageRect.left - imageRect.width / 2 + canvasRect.left;
				const y = downY - imageRect.top - imageRect.height / 2 + canvasRect.top;
				clickOffset = { x, y };
			}
		}
	};

	//---------------------
	// TEXT - ON DOWN
	//---------------------
	const onTextTouch = (e, index) => {
		var evt = (typeof e.originalEvent === 'undefined') ? e : e.originalEvent;
		var touch = evt.touches[0] || evt.changedTouches[0];
		onTextDown(touch.pageX, touch.pageY, index);
	}

	const onTextClick = (evt, index) => {
		onTextDown(evt.clientX, evt.clientY, index);
	}

	const onTextDown = (downX, downY, index) => {
		if (mode !== eMode.COLOUR_IMAGE) {
			dispatch(setMode(eMode.EDIT_TEXT));
		}
		dispatch(setDragIndex(index));
		dispatch(setSelectedIndex(index));
		updateData(index, "zIndex", getHighestZdepth(images) );

		//set offset to
		const canvasRect = document.getElementById("canvas").getBoundingClientRect();
		const imageEl = document.getElementById("text-" + index);
		if (imageEl) {
			const imageRect = imageEl.getBoundingClientRect();
			const x = downX - imageRect.left - imageRect.width / 2 + canvasRect.left;
			const y = downY - imageRect.top - imageRect.height / 2 + canvasRect.top;
			clickOffset = { x, y };
		}
	};

	const onUp = e => { 
		dispatch(setDragIndex(-1));
		if (mode === eMode.COLOUR_IMAGE) {
			dispatch(storeHistroy());
		}
		if (mode === eMode.EDIT_IMAGE) {
			dispatch(storeHistroy());
		}
	};

	//---------------------
	// ON MOVE
	//---------------------
	const onTouchMove = e => {
		var evt = (typeof e.originalEvent === 'undefined') ? e : e.originalEvent;
		var touch = evt.touches[0] || evt.changedTouches[0];
		onMove(touch.pageX, touch.pageY);
	}

	const onMouseMove = evt => {
		onMove(evt.clientX, evt.clientY);
	}

	const onMove = (moveX, moveY) => {
		const canvasRect = document.getElementById("canvas").getBoundingClientRect();
		const canvasInnerRect = document.getElementById("canvas-inner").getBoundingClientRect();
		const x = (moveX - canvasRect.left + (canvasRect.left - canvasInnerRect.left)) / canvasScale / zoom;
		const y = (moveY - canvasRect.top + (canvasRect.top - canvasInnerRect.top)) / canvasScale / zoom;
		setMousePos({ x, y }); // diff coords for transform widget as we need to use clickoffset
		window.mousex = x;
		window.mousey = y;
		if (dragIndex !== -1) {
			const x = (moveX - clickOffset.x + (canvasRect.left - canvasInnerRect.left)) / canvasScale / zoom;
			const y = (moveY - clickOffset.y + (canvasRect.top - canvasInnerRect.top)) / canvasScale / zoom;
			updateData(dragIndex, "x", x); 
			updateData(dragIndex, "y", y); 
		}
	};

	const setAngle = ang => {
		updateData(selectedIndex, "angle", ang);
	};

	const setSize = size => {
		updateData(selectedIndex, "size", size);
	};

	// const onUnlock = () => {
	// 	dispatch(setTemplateLock(!view.templateLock));
	// };

	const onPan = dir => {
		const STEP = 30;
		switch(dir){
			case eDirection.UP : setPany(pany - STEP); break;
			case eDirection.DOWN : setPany(pany + STEP); break;
			case eDirection.LEFT : setPanx(panx - STEP); break;
			case eDirection.RIGHT : setPanx(panx + STEP); break;
			case eDirection.IN : setZoom(zoom + 0.05); break;
			case eDirection.OUT : setZoom(zoom - 0.05); break;
			case eDirection.RESET : setZoom(1); setPanx(0); setPany(0); break;
			default: break;
		}
	};

	// ------------ STYLES ------------ 
	const calcImageStyle = (item, index) => {
		return  {
			position: "absolute",
			zIndex: item.zIndex,
			left: `${item.x - item.size / 2}px`,
			top: `${item.y - item.size / 2}px`,
			transform: `rotate(${item.angle}deg)`,
			border: selectedIndex === index && mode === eMode.EDIT_IMAGE && !brushColour ? `solid 3px var(--color-ui-canvas-control)` : `solid 3px transparent`,
			width: `${item.size}px`,
			height: `${item.size}px`,
		}
	}
	const calcTextStyle = (item, index) => {
		return  {
			position: "absolute",
			zIndex:`${item.zIndex}`,
			left: `${item.x - item.size / 2}px`,
			top: `${item.y - item.size / 3 / 2}px`,
			transform: `rotate(${item.angle}deg)`,
			border: selectedIndex === index && mode === eMode.EDIT_TEXT && !brushColour ? `solid 3px var(--color-ui-canvas-control)` : `solid 3px transparent`,
			width: `${item.size}px`,
			height: `${item.size / 4}px`,

			fontFamily:item.fontFamily,
			fontSize:`${item.fontSize}px`,
			textAlign:`${item.justify}`,
			fontStyle:item.italic ? "italic" : "normal",
			fontWeight:item.bold ? "bold" : "normal",
			color:item.colour,
		}
	}
	const templateStyle = orientation === "landscape" ? {
		width: `${768}px`,
		height: `${1100}px`,
		background: "var(--color-white)",
		transform: "translate(166px, -166px) rotate(90deg)"
	} : null;
	const canvasStyle = { transform: `scale(${canvasScale})`, left: `${canvasLeft}px`, top: canvasTop, clipPath: "none", background: "var(--color-background-white-subtle)"}
	const canvasInnerStyle = { transform: `scale(${zoom}) translate(${panx}px, ${pany}px)` };
	
	return (
		<div 	className={cx("page")}
				onTouchMove={onTouchMove}
				onMouseMove={onMouseMove}
				onMouseUp={onUp}
				onTouchEnd={onUp}>

			<div 	id="canvas"
					className={cx(`canvas ${orientation}`)}
					style={canvasStyle}
					ref={canvasRef}
			>
				<div id="canvas-inner" style={canvasInnerStyle}>
					{template &&
						<div id='template'
							className={cx('template')}
							style={templateStyle} // NEEDS STYLE width/height for LANDSCAPE print
							onMouseDown={evt => onImageClick(evt, 0, eMode.EDIT_TEMPLATE)}
							onTouchStart={evt => onImageTouch(evt, 0, eMode.EDIT_TEMPLATE)}
							dangerouslySetInnerHTML={{ __html: template.svg }}
						/>
					}
					{/* NOTE - needed to use class for clippath because inline styles didn't work for printing */}
					<div className={orientation === "landscape" ? "clipPathLandscape" : "clipPathPortrait"}>
						{images.map((item, index) => {
							const id = `image-${index}`;
							return (
								<div key={id} id={id}
									onMouseDown={evt => onImageClick(evt, index, eMode.EDIT_IMAGE)}
									onTouchStart={evt => onImageTouch(evt, index, eMode.EDIT_IMAGE)}
									style={{ ...calcImageStyle(item, index) }}
									dangerouslySetInnerHTML={{ __html: item.svg }}
								/>
							);
						})}
						{textData.map((item, index) => {
							const id = `text-${index}`;
							return (
								<div key={id} id={id}
									onMouseDown={evt => onTextClick(evt, index)}
									onTouchStart={evt => onTextTouch(evt, index)}
									style={calcTextStyle(item, index)}>
									{item.text}
								</div>
							);
						})}
					</div>

					{brushColour && mode === eMode.COLOUR_IMAGE &&
						<div style={{position:"absolute", left: `${mousePos.x}px`, top: `${mousePos.y-150/zoom}px`, pointerEvents:"none"}}>
							<BrushSVG id="brush-tip" width={150/zoom} height={150/zoom}/>
						</div>
					}

				</div>

				{/* ---- transform widget ---- */}
				<div style={{transform:`scale(${zoom}) translate(${panx}px, ${pany}px)`}}>
					<div>
						{(!brushColour && (textData[selectedIndex] || images[selectedIndex]) && (mode === eMode.EDIT_IMAGE || mode === eMode.EDIT_TEXT)) &&
							<TransformWidget
								item={mode === eMode.EDIT_TEXT ? textData[selectedIndex] : images[selectedIndex]}
								mousePosX={mousePos.x}
								mousePosY={mousePos.y}
								setAngle={setAngle} // TODO doesn't need to come back to App.js
								setSize={setSize} // TODO doesn't need to come back to App.js
								type={mode === eMode.EDIT_TEXT ? "text" : null}
							/>
						}
					</div>
				</div>
			</div>

			{/* controls */}
			{!view.fullScreen &&
			<div className={cx(view.mode === eMode.SAVE_PROJECT ? "saving" : null)}>
				<div onMouseDown={evt => onPan(eDirection.UP)} className={cx("canvas-icon pan up")}/>
				<div onMouseDown={evt => onPan(eDirection.DOWN)} className={cx("canvas-icon pan down")}/>
				<div onMouseDown={evt => onPan(eDirection.LEFT)} className={cx("canvas-icon pan left")}/>
				<div onMouseDown={evt => onPan(eDirection.RIGHT)} className={cx("canvas-icon pan right")}/>
				<div onMouseDown={evt => onPan(eDirection.IN)} className={cx("canvas-icon zoom in")}>+</div>
				<div onMouseDown={evt => onPan(eDirection.OUT)} className={cx("canvas-icon zoom out")}>-</div>
				<div onMouseDown={evt => onPan(eDirection.RESET)} className={cx("canvas-icon reset")}/>
			</div>
			}
			{/*
			----------------------------------------------------
			BOXVIEW ONLY - so it appears outside of canvas area
			----------------------------------------------------
			 */}

			<div className={cx(`canvas-controls ${orientation}`)} style={{ opacity:"0.2", pointerEvents: "none", transform: `scale(${canvasScale})`, left:`${canvasLeft}px`}}>
				<div style={{transform:`scale(${zoom}) translate(${panx}px, ${pany}px)`}}>
					{images.map((item, index) => {
						const id = `image-viewonly-${index}`;
						const key = id;
						return (
							<div key={key} id={id} style={calcImageStyle(item, index)}/>
						);
					})}
					{textData.map((item, index) => {
						const id = `text-viewonly-${index}`;
						return (
							<div key={id} id={id} style={calcTextStyle(item, index)}/>
						);
					})}
				</div>
			</div>
		</div>
		
	);
}

export default Canvas;

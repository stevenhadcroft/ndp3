// Special category: user-uploaded images, sourced from local disk rather than
// the bundled XML image library — handled separately from the other categories.
export const MY_IMAGES_CATEGORY_ID = "myImages";

export const IMAGE_CATEGORIES = [
    { title: "All word categories", id: "All" },
    { title: "Single Consonant", id: "cons" },
    { title: "Single Vowel", id: "vow" },
    { title: "CV words", id: "CVword" },
    { title: "VC words", id: "VCword" },
    { title: "CVC words", id: "CVCword" },
    { title: "CVCV ending cues", id: "CVCVend" },
    { title: "CVCV characters", id: "CVCVchar" },
    { title: "CVCVC verbs", id: "CVCVCverb" },
    { title: "CVCV words", id: "CVCVword" },
    { title: "CVCVC words", id: "CVCVCword" },
    { title: "Multisyllabic", id: "msyl" },
    { title: "/s/ clusters", id: "Sclus" },
    { title: "/i/ clusters", id: "Iclus" },
    { title: "/r/ clusters", id: "Rclus" },
    { title: "Medial clusters", id: "medial" },
    { title: "Final clusters", id: "final" },
    { title: "2 Word phrases & sentences", id: "words2" },
    { title: "Everyday phrases", id: "every" },
    { title: "Complex sentences", id: "complex" },
    { title: "Articulograms", id: "artic" },
    { title: "Jolly", id: "jolly" },
    { title: "Assessment", id: "asses" },
    { title: "My Images", id: MY_IMAGES_CATEGORY_ID },
];

export const WORKSHEET_CATEGORIES = [
    { title: "All", id: "" },
    { title: "Sequencing", id: "Wseq" },
    { title: "Transition", id: "trans" },
    { title: "Voice", id: "voice" },
    { title: "Grids", id: "grids" },
    { title: "Cards and Stickers", id: "card" },
    { title: "Games", id: "games" },
];

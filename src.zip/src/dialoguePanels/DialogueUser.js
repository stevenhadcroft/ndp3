import { useRef } from "react";
import { useSelector, useDispatch } from 'react-redux';
import { cx } from '../styles';
import { eMode } from "../constants";
import Swal from 'sweetalert2';

// import {
//     setUserName,
// } from '../actions'

import {
    resetCanvas,
} from "../features/canvasSlice";

import {
    setMode,
    setUserIsAuth,
    setUnlockCount,
} from "../features/viewSlice";

import DraggablePanel from "./DraggablePanel";
import { getUser, createUser } from "../services/userMananger";
import {linkMachine, unlinkMachine, saveUnlockCount} from '../services/localLicenseMananger';
import {validateKey, generateKey} from '../utils';
import useDefaultTemplate from "../hooks/useDefaultTemplate";

// Dev bypass fully unlocks the side-menu items too (see below).
const DEV_BYPASS_UNLOCK_COUNT = 99999;

// TEMP: skip the getUser server round-trip on sign-in — a valid licence key
// is enough to authenticate locally. Flip back to false to restore the
// server check (see the getUser(...) call further down in onSignIn).
const SKIP_SERVER_SIGN_IN = true;


const DialogueUser = () => {

    const dispatch = useDispatch();
    const view = useSelector(state => state.view);
    const loadDefaultTemplate = useDefaultTemplate();
    // const inputRef = useRef();
    const inputRefSignInEmail = useRef();
    const inputRefSignInPassword = useRef();
    // const inputRefRegisterKey = useRef();
    const inputRefRegisterName = useRef();
    const inputRefRegisterEmail = useRef();
    const inputRefRegisterPassword = useRef();
    const inputRefRegisterPassword2 = useRef();

    const flex = {flex:"1", margin:"10px 20px"};
    const center = {whiteSpace:"nowrap", width:"100%", textAlign:"center"}


    // HANDLERS ---------------------------------------------------
    const onSignIn = async () => {

        const email = inputRefSignInEmail.current.value;
        const key = inputRefSignInPassword.current.value;
        // Z4Z4M7

        if (!email){
            Swal.fire({
                title: 'Error!',
                text: 'Please complete all details',
                icon: 'error',
                confirmButtonText: 'Continue'
            })
            return;
        }

        //-----dev bypass: skip key validation and the login API entirely
        if (key === 'Cliff-Richard-Rocks'){
            dispatch(resetCanvas());
            loadDefaultTemplate(false);
            dispatch(setMode(eMode.USER_ACTIVE))
            dispatch(setUserIsAuth(true))
            linkMachine(email);
            saveUnlockCount(DEV_BYPASS_UNLOCK_COUNT, email);
            dispatch(setUnlockCount(DEV_BYPASS_UNLOCK_COUNT));
            return;
        }

        //-----check key (must match email) — also decodes the unlock number
        const keyResult = await validateKey(key, email);
        if (!keyResult){
            Swal.fire({
                title: 'Error!',
                text: 'Key not valid',
                icon: 'error',
                confirmButtonText: 'Continue'
              })
            return;
        }

        //-----TEMP: bypass getUser() — a valid key signs the user in directly
        if (SKIP_SERVER_SIGN_IN){
            dispatch(resetCanvas());
            loadDefaultTemplate(false);
            dispatch(setMode(eMode.USER_ACTIVE))
            dispatch(setUserIsAuth(true))
            linkMachine(email);
            saveUnlockCount(keyResult.number, email);
            dispatch(setUnlockCount(keyResult.number));
            return;
        }

        // moved from using password to key
        const data = { email, password: '' };
        let response;
        try {
            response = await getUser(data);
        } catch (error) {
            Swal.fire({
                title: 'Error!',
                text: error.message,
                icon: 'error',
                confirmButtonText: 'Continue'
            })
            return;
        }

        if (response.complete === 1 && response.approval === "approved") {

            //clear out old data
            dispatch(resetCanvas());
            loadDefaultTemplate(false);
            dispatch(setMode(eMode.USER_ACTIVE))
            dispatch(setUserIsAuth(true))
            linkMachine(email);
            saveUnlockCount(keyResult.number, email);
            dispatch(setUnlockCount(keyResult.number));

        } else if (response.complete === 1 && response.approval !== "approved") {
            dispatch(setMode(eMode.USER_OPTIONS))
            Swal.fire({
                title: 'Account pending',
                text: 'Your account is pending approval',
                icon: 'warning',
                footer: 'For more info contact&nbsp;<a href="info@ndp3.org">info@ndp3.org</a>',
                confirmButtonText: 'Close'
            })

        } else {
            Swal.fire({
                title: 'Error!',
                text: 'User not found or login detail incorrect',
                icon: 'error',
                confirmButtonText: 'Continue'
            })
            unlinkMachine(email);
            return false;
        }
    }

    const onRegister = async (col) => {

        // const key = inputRefRegisterKey.current.value;
        const key = inputRefRegisterPassword.current.value;
        const name = inputRefRegisterName.current.value;
        const email = inputRefRegisterEmail.current.value;
        const password = inputRefRegisterPassword.current.value;
        const passwordConfirm = inputRefRegisterPassword2.current.value;

        if (!key || !name || !email || !password){
            Swal.fire({
                title: 'Error!',
                text: 'Please complete all details',
                icon: 'error',
                confirmButtonText: 'Continue'
              })
              return false;
        }

        //-----check key (must match email)
        if (!(await validateKey(key, email))){
            Swal.fire({
                title: 'Error!',
                text: 'Key not valid',
                icon: 'error',
                confirmButtonText: 'Continue'
              })
            return;
        }

        if (password !== passwordConfirm){
            Swal.fire({
                title: 'Error!',
                text: 'Passwords must be the same',
                icon: 'error',
                confirmButtonText: 'Continue'
              })
            return;
        }

        const data = { key, name, email, password};

        // console.log(data);
        createUser(data)
            .then((response) => {
                console.log('response ', response);
                if (response.complete === 1){
                    // setShow(eMode.USER_SIGN_IN);
                    Swal.fire({
                        title: 'Success!',
                        text: 'Your account has been created.',
                        icon: 'success',
                        footer: 'Please sign in to continue.',
                        confirmButtonText: 'Sign In'
                    })
                    dispatch(setMode(eMode.USER_SIGN_IN))
                } else {
                    // alert("user not found")
                    Swal.fire({
                        title: 'Error!',
                        text: response.message, /// /'Uesr alInvalid details or ',
                        icon: 'error',
                        confirmButtonText: 'Continue'
                      })
                }
            })
            .catch((error) => {
                Swal.fire({
                    title: 'Error!',
                    text: error.message,
                    icon: 'error',
                    confirmButtonText: 'Continue'
                })
            })
    }

    //--------------------------------------------------------------
    // Buttons Component
    //--------------------------------------------------------------

    const Buttons = (
        <>
            <button className={cx("primary narrow")} onClick={() => { }}>Done</button>
        </>
    )

    const Container = ({ children }) =>
        <div style={{ position: "absolute", top: "50px", left: "0", width: "100%", height: "100%", background: "var(--color-background-app)" }}>
            {children}
        </div>


    //--------------------------------------------------------------
    // Sign in 
    //--------------------------------------------------------------
    const Options = () =>
        <DraggablePanel central={true} id='sign-in' title="Options">   {/* buttons={Buttons} */}
            <div style={{ textAlign: 'center'}}>
                <button className={cx("primary narrow")} onClick={() => { dispatch(setMode(eMode.USER_SIGN_IN)) }}>Sign In</button>
                <div style={{ height: "20px" }} />
                <button className={cx("primary narrow")} onClick={() => { dispatch(setMode(eMode.USER_REGISTER)) }}>Register</button>
                <div style={{ height: "20px" }} />
            </div>
            {/* {generateKey()} */}
        </DraggablePanel>

    //--------------------------------------------------------------
    // Sign in 
    //--------------------------------------------------------------
    const SignIn = () =>
        <DraggablePanel central={true} id='sign-in' title="Sign In">   {/* buttons={Buttons} */}
            <div style={{ padding: '0 50px' }}>

                <div style={{ fontWeight: "normal" }}>Email / Username</div>
                <br /><input style={{ width: "100%" }} name="email" type="text" className="rounded" ref={inputRefSignInEmail} />

                <div style={{ height: "20px" }} />

                <div style={{ fontWeight: "normal" }}>Licence key</div>
                <br /><input style={{ width: "100%" }} name="password" type="text" className="rounded" ref={inputRefSignInPassword} />

                <div style={{ height: "50px" }} />

                <div style={center}>
                    <button className={cx("secondary narrow")} onClick={()=>dispatch(setMode(eMode.USER_OPTIONS))}>Cancel</button>
                    <button className={cx("primary narrow")} onClick={onSignIn}>Submit</button>
                </div>

                <div style={{ height: "20px" }} /> 

            </div>
        </DraggablePanel>

    //--------------------------------------------------------------
    // Register
    //--------------------------------------------------------------
    
    const Register = () =>
        <DraggablePanel central={true} id='sign-up' title="Sign Up">
            {/*  */}
            <div style={{ padding: '0 20px' }}>

                {/* <div style={{ display: "flex" }}>
                    <div style={flex}>
                        <div style={{ fontWeight: "bold" }}>Licence Key</div>
                        <br /><input type="text" className="rounded" ref={inputRefRegisterKey} />
                    </div>
                </div> */}

                {/* <div style={{ height: "20px" }} /> */}

                <div style={{ display: "flex" }}>
                    <div style={flex}>
                        <div style={{ fontWeight: "normal" }}>Name</div>
                        <br /><input type="text" className="rounded" ref={inputRefRegisterName} />
                    </div>
                    <div style={flex}>
                        <div style={{ fontWeight: "normal" }}>Email</div>
                        <br /><input type="text" className="rounded" ref={inputRefRegisterEmail} />
                    </div>
                </div>

                <div style={{ height: "20px" }} />

                <div style={{ display: "flex" }}>
                    <div style={flex}>
                        <div style={{ fontWeight: "normal" }}>Licence key</div>
                        <br /><input type="text" className="rounded" ref={inputRefRegisterPassword} />
                    </div>
                    {/* <div style={{ height: "30px" }} /> */}
                    <div style={flex}>
                        <div style={{ fontWeight: "normal" }}>Re-enter licence key</div>
                        <br /><input type="text" className="rounded" ref={inputRefRegisterPassword2} />
                    </div>
                </div>

                <div style={{ height: "50px" }} />

                <div style={center}>
                    <button className={cx("secondary narrow")} onClick={()=>dispatch(setMode(eMode.USER_OPTIONS))}>Cancel</button>
                    <button className={cx("primary narrow")} onClick={onRegister}>Submit</button>
                </div>
                
            </div>
        </DraggablePanel>


    return (
        <>
            {view.mode === eMode.USER_PENDING &&
                <Container>
                </Container>
            }
            {view.mode === eMode.USER_OPTIONS &&
                <Container>
                    <Options />
                </Container>
            }
            {view.mode === eMode.USER_REGISTER &&
                <Container>
                    <Register />
                </Container>
            }
            {view.mode === eMode.USER_SIGN_IN &&
                <Container>
                    <SignIn />
                </Container>
            }
        </>
    );
}

export default DialogueUser;